function LayerLoginEnter() {}

LayerLoginEnter.prototype.onDidLoadFromCCB = function() {
    cc.Director.getInstance().setDisplayStats(false);

    var dataGlobal = DataController.getInstance().getDataGlobal();
    dataGlobal.loadRecord();

    this.updateLoginServer();

    cc.log("fuck...fuck...fuck...fuck...fuck...");

    if (dataGlobal.allowPlayBackGround()) {
        cc.AudioEngine.getInstance().playMusic(g_musicMainName, true);
    }

    this.rootNode.onEnterTransitionDidFinish = function() {
        this.controller.onEnterTransitionDidFinish();
    };

    // TEST
    // var size = cc.size(300, 300);
    // var len = size.width / 2 / Math.cos(18 / 180 * Math.PI);
    // var origin = cc.p(size.width / 2, size.height - len);
    // var percents = [0.5, 0.6, 0.7, 0.8, 0.9];
    // // var percents = [1, 1, 1, 1, 1];
    // var points = [],
    //     i;
    // for (i = 0; i < 5; ++i) {
    //     angle = (18 + (72 * i)) / 180 * Math.PI;
    //     x = origin.x + percents[i] * len * Math.cos(angle);
    //     y = origin.y + percents[i] * len * Math.sin(angle);
    //     points[i] = cc.p(x, y);
    // }
    // var vec = [];
    // for (i = 0; i < 5; ++i) {
    //     var arr = [];
    //     arr.push(origin);
    //     arr.push(points[i]);
    //     arr.push(points[(i + 1) % 5]);
    //     vec.push(arr);
    // }

    // var render = cc.RenderTexture.create(size.width, size.height,
    //     cc.TEXTURE_PIXELFORMAT_RGBA8888);
    // render.begin();
    // var drawNode = cc.DrawNode.create();
    // for (i = 0; i < 5; ++i) {
    //     drawNode.drawPoly(vec[i], cc.c4f(1, 1, 1, 1), 0, cc.c4f(1, 0, 0, 1));
    // }
    // drawNode.visit();
    // render.end();

    // // render.getSprite().getTexture().setAliasTexParameters();
    // render.getSprite().getTexture().setAntiAliasTexParameters();

    // render.setPosition(cc.p(150, 150));
    // this.rootNode.addChild(render, 20000);

    // var clippingNodeInner = cch.ClippingNode.create();
    // clippingNodeInner.setContentSize(sizeNode);
    // spriteStencil.setAnchorPoint(cc.POINT_ZERO);
    // clippingNodeInner.setStencil(spriteStencil);
    // clippingNodeInner.addChild(node0);
    // clippingNodeInner.setAlphaThreshold(0.05);
    // clippingNodeInner.setAnchorPoint(cc.p(0.5, 0.5));
    // clippingNodeInner.setPosition(posNode);

    // this.rootNode.addChild(clippingNodeInner);
};

LayerLoginEnter.prototype.onPressAccountBound = function() {
    LayerLogin.getInstance().pushLayer(
        LayerAccountBound.create(this), TChangeType.ESliderFromRight);
};

LayerLoginEnter.prototype.updateLoginServer = function() {
    // account
    var dataGlobal = DataController.getInstance().getDataGlobal();
    var userAccount = dataGlobal.getAccount();
    if (userAccount && userAccount.length > 0) {
        this.m_spriteLogin.setVisible(false);
        this.m_labelLoginAccount.setString(userAccount);
    }

    // login server
    var loginServerId = dataGlobal.getServerId();
    this.m_labelLoginServerId.setString(loginServerId);
    if (dataGlobal.getQuickUser()) {
        var norm, select, enble;
        norm = cc.LabelTTF.create("帐号绑定", "Helvetica", 12);
        select = cc.LabelTTF.create("帐号绑定", "Helvetica", 12);
        enble = cc.LabelTTF.create("帐号绑定", "Helvetica", 12);
        norm.setColor(cc.GREEN);
        select.setColor(cc.GREEN);
        select.setPosition(cc.p(0, -1));
        enble.setColor(cc.GREEN);
        var menuItem = cc.MenuItemSprite.create(norm, select, enble,
            this.onPressAccountBound, this);
        menuItem.setAnchorPoint(this.m_btAccountBoundMenu.getAnchorPoint());
        var size = this.m_btAccountBoundMenu.getContentSize();
        menuItem.setPosition(cc.p(size.width / 2, size.height / 2));
        this.m_btAccountBoundMenu.addChild(menuItem);
    } else {
        this.m_btAccountBoundMenu.setVisible(false);
    }
};

LayerLoginEnter.prototype.onEnterTransitionDidFinish = function() {
    // connect socket for send app start
    var logiclogin = LogicController.getInstance().getLogicLogin();
    logiclogin.setDelegate(this);
    logiclogin.sendAppStartPacket();
    cc.log("cacacaca,miaolegemide....");
};

LayerLoginEnter.prototype.onPressLand = function(INsender) {
    LayerLogin.getInstance().pushLayer(
        LayerLoginLand.create(), TChangeType.ESliderFromRight);
};

LayerLoginEnter.prototype.onPressServer = function(INsender) {
    LayerLogin.getInstance().pushLayer(
        LayerLoginServer.create(), TChangeType.ESliderFromRight);
};

LayerLoginEnter.prototype.onPressFastLogin = function(INsender) {
    this.m_menuItemFastLogin.setEnabled(false);
    this.m_menuItemAccount.setEnabled(false);
    this.m_menuItemServer.setEnabled(false);

    var logiclogin = LogicController.getInstance().getLogicLogin();
    logiclogin.setDelegate(this);
    logiclogin.startLoginProcess();
};

LayerLoginEnter.prototype.dealWithLoginError = function() {
    this.m_menuItemFastLogin.setEnabled(true);
    this.m_menuItemAccount.setEnabled(true);
    this.m_menuItemServer.setEnabled(true);
};

LayerLoginEnter.create = function() {
    var layer = cc.BuilderReader.load("LayerLoginEnter");
    return layer;
};